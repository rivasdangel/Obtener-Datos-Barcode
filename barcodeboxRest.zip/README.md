# nodejs-rest-serial

Sandbox for create a Server with Rest Services with NodeJS. This project not use Socket.IO!!

## Usage



## Developing



### Tools

* NodeJS 4
* Express 4
* Eclipse Luna with plugin for NodeJS