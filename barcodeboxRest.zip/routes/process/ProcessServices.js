var	log		= require('log4js').getLogger('app')
	,path	= require('path')
	,fs		= require('fs');


var saveDataSerialBox = function(request, callback){
	var resp = {};
	resp.success = false;
	resp.code = -1;
	resp.msg = "No ok default";
	resp.data = null;

	try{
		//log.info(request);
		//log.info('-------------------------');
		//log.info(request.body);

		var data = request.body;
		var idLine = data.idLine;
		var record = data.record;
		log.info('ProcessServices|saveDataSerialBox|data: ' + JSON.stringify(data));

		var fileName = configAppGlobal.dataLogs.path + '\\' + idLine + '_LOGS\\' + configAppGlobal.dataLogs.serialBoxFileName + idLine.toLowerCase() + '.log';
		log.info('ProcessServices|saveDataSerialBox|fileName: ' + fileName);

		if(record != null || record != ''){
			var dateCreation = new Date(record.date_creation).getTime();
			//var dateCreation = new Date().getTime();

			var lineData = 'tt=' + dateCreation + ',var=' + record.units + ',val=' + record.weight + ',typ=can' + '\n';

			fs.appendFileSync(fileName, lineData);

			resp.success = true;
			resp.code = 1;
			resp.msg = 'ok';
		}

		return callback(resp);

	}catch(Exception){
		log.error('ProcessServices|saveDataSerialBox|Exception: ' + Exception.stack);
	}
};

var saveDataBarcodeBox = function(request, callback){
	var resp = {};
	resp.success = false;
	resp.code = -1;
	resp.msg = "No ok default";
	resp.data = null;

	try{
		//log.info(request);
		//log.info('-------------------------');
		//log.info(request.body);

		var data = request.body;
		var idLine = data.idLine;
		var record = data.record;
		log.info('ProcessServices|saveDataBarcodeBox|data: ' + JSON.stringify(data));

		var fileName = configAppGlobal.data.dataLogs.path + '\\' + idLine + '_LOGS\\' + configAppGlobal.data.dataLogs.barcodeBoxFileName + idLine.toLowerCase() + '.log';
		log.info('ProcessServices|saveDataBarcodeBox|fileName: ' + fileName);

		if(record != null || record != ''){
			var dateCreation = new Date(record.date_creation).getTime();
			//var dateCreation = new Date().getTime();
			var barcode=record.read_data;
			if(barcode=="ERROR"){
				barcode=0;
			}else{
				if(barcode.length<13){
					barcode=0;
				}
			}
			var lineTxt = 'tt=' + dateCreation + ',var=bc,val=' + barcode + '\n';

			fs.appendFileSync(fileName, lineTxt);
			if(idLine == 'L13'){
				let fileName = configAppGlobal.data.dataLogs.path + '\\' + idLine + '_LOGSFAKE\\' + configAppGlobal.data.dataLogs.barcodeBoxFileName + idLine.toLowerCase() + '.log'
				fs.appendFileSync(fileName, lineTxt)
			}
			resp.success = true;
			resp.code = 1;
			resp.msg = 'ok';
		}

		return callback(resp);

	}catch(Exception){
		log.error('ProcessServices|saveDataBarcodeBox|Exception: ' + Exception.stack);
	}
};


var saveDataWise = function(request, callback){
	var fileName = null;
	var resp = {};
	resp.success = false;
	resp.code = -1;
	resp.msg = "No ok default";
	resp.data = null;

	try{
		//log.info(request);
		//log.info('-------------------------');
		//log.info(request.body);


		/**************************************
		 * Modificar para logica de negocio en implementacion del WISE
		 * ST 	// 1-4 1:RUN, 2:STOP, 3:WAIT, 4:BLOCK
		 * CPQI //Counter Product Quantity In
		 * CPQO //Counter Product Quantity Out
		 * SP	//difference on output - input
		 */
		var ST, CPQI, CPQO, SP, countOutOld, record, countOutNow, countOutOld;

		data = request.body;
		log.info('ProcessServices|saveDataBarcodeBox|data: ' + JSON.stringify(data));
//		request: {"PE":128,"UID":"WISE-4051_00D0C9F936F9",
//		"MAC":"00-D0-C9-F9-36-F9","TIM":"2017-04-06T14:54:28-06:00",
//		"Record":[[0,0,1,0],[0,1,2,4],[0,2,2,13],[0,3,1,0],[0,4,1,0],[0,5,1,1],[0,6,1,0],[0,7,1,0]]}
//	}

		log.info('ProcessServices|saveDataBarcodeBox|ST: ' + ST);
		ST = 2;

		if(data != null || data != ''){
			var pe = data.PE;
			var uid = data.UID;
			var mac = data.MAC;
			var timestamp = data.TIM;
			var datas = data.Record[0];

			if(uid == 'WISE-LINEA1'){
				fileName = 'C:\\Pulse\\L1_LOGS\\mex_cue_wise_l1.log';
			}


			var ch0 = datas[0];
			var ch1 = datas[1];
			var ch2 = datas[2];
			var ch3 = datas[3];
			var ch4 = datas[4];
			var ch7 = datas[5];
			var ch8 = datas[6];
			var ch9 = datas[7];

			var slot = ch0[0];
			var channel = ch0[1];
			var iotype = ch0[2]; //MODO 1 - DI, 2 - counter
			var value = ch0[3]; //value in counter mode, or status en di mode

			/*************************************
			 * TIME STOP FOR MACHINE
			 */
			var timeStopMachine = 10 * 1000;

			/*************************************
			 * Modificar para obtener datos de canales
			 */
			countInNow = ch3[3];
			countOutNow = ch0[3];
	        stBlockNow = ch2[3];
	        stWaitNow = ch1[3];



	        log.info('ProcessServices|saveDataBarcodeBox|countOutNow: ' + countOutNow);
	        log.info('ProcessServices|saveDataBarcodeBox|countOutOld: ' + countOutOld);
	        if(countOutNow > countOutOld){
	        	ST = 1;
	        	CPQI = countInNow;
	        	CPQO = countOutNow;
	        	SP = countOutNow - countOutOld;

	        	//TODO se guarda el tiempo de la peticion anterior
	        	// y si la diferencia de la peticion actual con la anterior es mayor
	        	// al tiempo de la maquina entonces si se guarda en el archivo
	        	// sino se salta y si cambio el status
	        	record = 'tt=' + new Date().getTime() + ',var=ST,val=' + ST + '\n';
	        	record += 'tt=' + new Date().getTime() + ',var=CPQI,val=' + CPQI + '\n';
	        	record += 'tt=' + new Date().getTime() + ',var=CPQO,val=' + CPQO + '\n';
	        	record += 'tt=' + new Date().getTime() + ',var=SP,val=' + SP + '\n';
	        	fs.appendFileSync(fileName, record);

	        }else{
	        	if(stWaitNow == 0 && (stBlockNow == 0 || stBlockNow == 1)){
	        		ST = 3;

	        	}else if(stWaitNow == 1 && stBlockNow == 0){
	        		ST = 2;

	        	}else if(stWaitNow == 1 && stBlockNow == 1){
	        		ST = 3;
	        	}

	        	log.info('ProcessServices|saveDataBarcodeBox|ST: ' + ST);

	        	record = 'tt=' + new Date().getTime() + ',var=ST,val=' + ST + '\n';
	        	record += 'tt=' + new Date().getTime() + ',var=CPQI,val=' + CPQI + '\n';
	        	record += 'tt=' + new Date().getTime() + ',var=CPQO,val=' + CPQO + '\n';
	        	record += 'tt=' + new Date().getTime() + ',var=SP,val=' + SP + '\n';
	        	//fs.appendFileSync(fileName, record);
	        }

	        countOutOld = countOutNow;
	        log.info('ProcessServices|saveDataBarcodeBox|countOutOld: ' + countOutOld);
	    	record = "";

			resp.success = true;
			resp.code = 1;
			resp.msg = 'ok';
		}

		return callback(resp);

	}catch(Exception){
		log.error('ProcessServices|saveDataBarcodeBox|Exception: ' + Exception.stack);
	}
};

module.exports = {
	saveDataSerialBox: saveDataSerialBox,
	saveDataBarcodeBox: saveDataBarcodeBox,
	saveDataWise: saveDataWise
}
