/**
 * Created by @Jakofff
 */
try{
	var	fs			= require('fs')
		,path 		= require('path')
		,log4js 	= require('log4js')
		,cors 		= require('cors')
		,express	= require('express')
		,bodyParser = require('body-parser')
		,http		= require('http')
		,methodOverride = require('method-override')
		,errorHandler = require('errorhandler');

	var pathApp 	= path.join(__dirname, '/')
		,configPath = path.join(pathApp, 'config/')
		,pathModules= path.join(pathApp, 'modules/')
		,pathRoutes	= path.join(pathApp, 'routes/')
		,pathViews	= path.join(pathApp, 'views/');

	var configFilename	= path.join(configPath, 'config.json')
		,logFilename 	= path.join(configPath, 'log4js.json');

	var fileUtil	= require(path.join(pathModules,'file'))
		,common  	= require(path.join(pathModules,'common'))
		,notifier   = require(path.join(pathModules,'notifier'))
		,routes 	= require(pathRoutes);

	var configApp = {}
		,log = null
		,server = null
		,options = {
			//key:fs.readFileSync('server.key'), //if require ssl
			//cert:fs.readFileSync('server.crt'), //if require ssl
		};

	configApp = fileUtil.readFileToJson(configFilename);
	if(configApp != null){
		try{
			log4js.configure(logFilename, { cwd: configApp.logsPath });
			log = log4js.getLogger('app');

			global.configAppGlobal 	= configApp;
			global.pathRootApp		= pathApp;
			global.pathModulesApp	= pathModules;
			global.pathRoutesApp	= pathRoutes;
			global.pathViewsApp		= pathViews;

			getVars();

			notifier.notify(0, "Start ProcessorBox App");

			var Process_Services =  require(path.join(pathRoutes, 'process/ProcessServices'));


			var app = express();

			app.set('host', configApp.host);
			app.set('port', configApp.port);
			app.set('env', configApp.env);
			app.use(cors());
			app.set('views', pathViews);
			app.set('view engine', 'jade');
			app.use(log4js.connectLogger(log4js.getLogger("http"), { level: 'auto' }));
			app.use(bodyParser.urlencoded({
				extended: true
			}));
			app.use(bodyParser.json());
			app.use(methodOverride());
			app.use(express.static(path.join(__dirname, 'public')));


			app.get('/', routes.index);


			app.post('/serialbox/save/data', function(request, response, next) {
				log.info('App ProcessorBox Rest|serialbox/save/data');

				Process_Services.saveDataSerialBox(request, function(jsonResponse) {
					log.info('App ProcessorBox Rest|barcodebox/save/data|response: ' + JSON.stringify(jsonResponse));

					response.setHeader("Content-Type", "application/json");
					response.send(jsonResponse);

					return response;
				});
			});

			app.post('/barcodebox/save/data', function(request, response, next) {
				log.info('App ProcessorBox Rest|barcodebox/save/data');

				Process_Services.saveDataBarcodeBox(request, function(jsonResponse) {
					log.info('App ProcessorBox Rest|barcodebox/save/data|response: ' + JSON.stringify(jsonResponse));

					response.setHeader("Content-Type", "application/json");
					response.send(jsonResponse);

					return response;
				});
			});

			app.post('/wise/save/data', function(request, response, next) {
				log.info('App ProcessorBox Rest|wise/save/data');

				Process_Services.saveDataWise(request, function(jsonResponse) {
					log.info('App ProcessorBox Rest|wise/save/data|response: ' + JSON.stringify(jsonResponse));

					response.setHeader("Content-Type", "application/json");
					response.send(jsonResponse);

					return response;
				});

				return response;
			});

			server = http.createServer(app);

			server.listen(app.get('port'), function(){
				log.info('App ProcessorBox Rest|start|App Port: ' + app.get('port') + '|onready!!!!');

			});

		}catch(Exception){
			console.log('App ProcessorBox Rest|Exception: ' + Exception.stack);
			notifier.notify(3, Exception.stack);
		}
	}


	function getVars(){
		console.log('------PATHS------');
		console.log(pathApp);
		console.log(pathModules);
		console.log(pathRoutes);
		console.log(configPath);
		console.log('------FILES CONFIG------');
		console.log(configFilename);
		console.log(logFilename);
		console.log('------PATHS GLOBLALS------');
		console.log(pathRootApp);
		console.log(pathModulesApp);
		console.log(pathRoutesApp);
		console.log('--------------------------');
	}

}catch(Exception){
	console.log('App ProcessorBox Rest|Exception: ' + Exception.stack);
}
